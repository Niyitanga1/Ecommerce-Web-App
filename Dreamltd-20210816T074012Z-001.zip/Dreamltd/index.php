﻿<?php
session_start();

?>
<!DOCTYPE html>
<html >
<head>
 
    <title>Dream Automobiles Ltd</title>



    <link href="assets/css/bootstrap.css" rel="stylesheet" />
	<link href="assets/css/font-awesome.min.css" rel="stylesheet" />

    <link href="assets/css/style.css" rel="stylesheet" />    
 
</head>
<body >
   
 <div class="navbar navbar-inverse navbar-fixed-top " id="menu">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <h1>Dream Automobiles Ltd</h1>
            </div>
            <div class="navbar-collapse collapse move-me">
                <ul class="nav navbar-nav navbar-right">
                    <li ><a href="#home">HOME</a></li>
                  
                    <li><a href="#our_products">OUR PRODUCTS</a></li>
                     <li><a href="#about">ABOUT US </a></li>
					  <li><a href="#course-sec">CONTACT US</a></li>
                     
                </ul>
            </div>
           
        </div>
    </div>
     
       <div class="home-sec"  id="home" style="height:300px">
           <div class="overlay">
 <div class="container" >
           <div class="row text-center " >
           
               <div class="col-lg-12  col-md-12 col-sm-12">
               
                <div class="flexslider set-flexi" id="main-section" >
                    <ul class="slides move-me">
                        <!-- Slider 01 -->
                        <li>
                             
                           <h2>Welcome</h2>
                           <h2>To Shop With us You have to first Sign in or Sign Up</h2>
                            <a  href="#features-sec" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#ln">
                                SIGN IN
                            </a>
                             <a  href="#features-sec" class="btn btn-success btn-lg" data-toggle="modal" data-target="#su">
                                SIGN UP
                            </a>
							
							<a  href="#features-sec" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#an">
                                ADMIN
                            </a>
                       
                          
                           
                </div>
                   
     
              
              
            </div>
                
               </div>
                </div>
           </div>
           
       </div>
       <!--HOME SECTION END-->   
    <div  class="tag-line" >
         <div class="container">
           <div class="row  text-center" >
           
               
               </div>
             </div>
        
    </div>
 
   <!-- FEATURES SECTION END-->
    <div id="our_products" style="background-color: rgba(245,247,249,1.00);color: rgba(0,0,0,1.00)">
    <div class="container set-pad">
             <div class="row text-center" >
                 <div class="col-lg-8 col-lg-offset-2 col-md-8 col-sm-8 col-md-offset-2 col-sm-offset-2">
                     <h1 data-scroll-reveal="enter from the bottom after 0.1s" class="header-line" style="color: rgba(0,0,0,1.00)">Our Products And services</h1>
                     <p data-scroll-reveal="enter from the bottom after 0.3s">
                      
                         </p>
                 </div>

             </div>
             <!--/.HEADER LINE END-->

           <div class="row" style="background-color: rgba(249,251,252,1.00);color: rgba(0,0,5,1.00)" >
           
               
           <table  border="1" align="center" style=" border-color: aliceblue;">
	
	<TR><td>
	

		
		<center>
			<img src="15537_7268001912898.jpg" height="200" width="300"/>
      <h4>Toyota Coaster</h4>
		<h3>Price:60M</h3>
		
		<a href="index.php"><button class="button"  >Order Now</button></a>
		</center>
		
		</td> 
	 <td><img src="istockphoto-1034249292-612x612.jpg" height="200" width="300"/>
		<br>
		<center>
		 <h4>Toyota Coaster</h4>
		<h3>Price:60M</h3>
		
		<a href="index.php"><button class="button"  >Order Now</button></a>
		</center>
	 <td> <img src="model-CBR600RR.jpg" height="200" width="300"/>
		<br>
		<center><h3>Price:1,500,000 rwf</h3>
			
	
    <a href="index.php"><button class="button"  >Order Now</button></a></center></td></TR>
	 
	 <tr><td>
		 <img src="download.jfif" height="200" width="300"/>
		<br>
		<center><h3>Price:70,000,000 rwf</h3>
			
	
		 <<a href="index.php"><button class="button"  >Order Now</button></a></center></td>
		 
		 </td>
	<td>
	 <img src="dfdbe4b1b5e9be06b01080cacaf62c2d.jpg" height="200" width="300"/>
		<br>
		<center><h3>Price:1,350,000 rwf</h3>
			
    <a href="index.php"><button class="button"  >Order Now</button></a></center>
	
	</td>
	
	
	<td>
	 <img src="images (1).jfif" height="200" width="300"/>
		<br>
		<center><h3>Price:90,000 rwf</h3>
			
	
		<a href="index.php"><button class="button"  >Order Now</button></a></center>
	
	</td>
	
	
	 
	 
	 
	 
	 
	 
	 </tr>
	
	
	</table>
              
                 
               </div>
             </div>
        </div>
		
		<div id="about" class="container set-pad" >
             <div class="row text-center">
                 <div class="col-lg-8 col-lg-offset-2 col-md-8 col-sm-8 col-md-offset-2 col-sm-offset-2">
                     <h1 data-scroll-reveal="enter from the bottom after 0.2s"  class="header-line">About Us</h1>
                     <p>It all started back in 1977, when two entrepreneurial minded Gorajia brothers were seeking a business opportunity in TRwanda, Kigali. The two brothers came upon a car dealership. With a hard working, determined, passionate and business minded personality, the those brothers were able to create the dealership of cars,
                        which till today stands as one of Rwanda landmarks. Building on the success of the dealership,
                         manufacturing brands nominated Dream Automobiles  as the exclusive distributor for those respective brands for the territory of Rwanda in 1997.
                          As more business ventures were added to the business portfolio, Dream Autombobiles was transformed to Dream Automobiles  LTD in 2008.

Dream Automobiles Ltd was established in Kigali, Rwanda and diversified into nine different divisions dealing in automobiles, Spare Parts, Second hand cars  and Motor cycles ,. Currently Dream Automobiles Ltd has itâ€™s presence in Uganda, Rwanda, Kenya& Eastern Democratic Republic Of Congo . Dream Automobiles has 250 plus employees, inclusive of approximately 20 plus expatriates of different nationalities 

</p>
						 
					 
                 </div>

             </div>
             <!--/.HEADER LINE END-->

<div class="container">
           <div class="row" >
           
               
          
				   
				  
                 
				 <div class="col-lg-12">
				 
                    
                   </div>
                 
                 </div>
               </div>
             </div>
			 <br />
    <!-- FACULTY SECTION END-->
      <div id="course-sec" class="container set-pad">
             <div class="row text-center">
                 <div class="col-lg-8 col-lg-offset-2 col-md-8 col-sm-8 col-md-offset-2 col-sm-offset-2">
                     <h1 data-scroll-reveal="enter from the bottom after 0.1s" class="header-line">Contact Us</h1>
                     <p data-scroll-reveal="enter from the bottom after 0.3s">
                      If you have any questions, please feel free to contact us, our customer service center is working for you 24/7.
					  <br />For more details. See the contact information below.
                         </p>
                 </div>

             </div>
             <!--/.HEADER LINE END-->

<br />
           
             <div class="container">
             <div class="row set-row-pad"  >
    <div class="col-lg-4 col-md-4 col-sm-4   col-lg-offset-1 col-md-offset-1 col-sm-offset-1 " data-scroll-reveal="enter from the bottom after 0.4s">

                    <h2 ><strong>Our Location </strong></h2>
        <hr />
                    <div ">
                        <h4>Kigali-Rwanda</h4>
                        <h4>CHIC Building(E33)- Near BK Entrance</h4>
						
                        
                    </div>


                </div>
                 <div class="col-lg-4 col-md-4 col-sm-4   col-lg-offset-1 col-md-offset-1 col-sm-offset-1" data-scroll-reveal="enter from the bottom after 0.4s">

                    <h2 ><strong>Feedbacks </strong></h2>
        <hr />
                    <div >
                        <h4><strong>Call:</strong>  +250 789251349 </h4>
                        <h4><strong>Email: </strong>dreamautomobiles@gmail.com</h4>
                        <h4><strong>Facebook: </strong>dreamautomobiles Rwanda</h4>
                        <h4><strong>Twitter: </strong>@dreamautomobiles_rw</h4>
                        <h4><strong>Instagram: </strong>dreamautomobiles_rw</h4>
                    </div>
                    </div>


                </div>
                 </div>
                 
                 
               </div>
             </div>
      <!-- COURSES SECTION END-->
     <div class="modal fade" id="su" tabindex="-1" role="dialog" aria-labelledby="myMediulModalLabel">
          <div class="modal-dialog modal-sm">
            <div style="color:white;background-color:#008CBA" class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Registration Form</h4>
              </div>
              <div class="modal-body">
            
				
				 <form role="form" method="post" action="register.php">
                   <fieldset>
					
							<div class="form-group">
                                <input class="form-control" placeholder="Firstname" name="ruser_firstname" type="text" required>
							</div>
							
							<div class="form-group">
                                <input class="form-control" placeholder="Lastname" name="ruser_lastname" type="text" required>
							</div>
																													<div class="form-group">
                                <input class="form-control" placeholder="National ID" name="ruser_nid" type="number" required>
							</div>
							
							<div class="form-group">
                                <input class="form-control" placeholder="country" name="ruser_address" type="text" required>
							</div>

              <div class="form-group">
                                <input class="form-control" placeholder="Province" name="ruser_province" type="text" required>
							</div>
              <div class="form-group">
                                <input class="form-control" placeholder="District" name="ruser_district" type="text" required>
							</div>

              <div class="form-group">
                                <input class="form-control" placeholder="Sector" name="ruser_sector" type="text" required>
							</div>

              <div class="form-group">
                                <input class="form-control" placeholder="Cell" name="ruser_cell" type="text" required>
							</div>

              <div class="form-group">
                                <input class="form-control" placeholder="Street No" name="ruser_streetno" type="text" required>
							</div>
							
                            <div class="form-group">
                                <input class="form-control" placeholder="Email" name="ruser_email" type="email" required>
							</div>
																											   
																											                               <div class="form-group">
                                <input class="form-control" placeholder="Telephone" name="ruser_tel" type="Number" required>
							</div>
							

							<div class="form-group">
                                <input class="form-control" placeholder="Password" name="ruser_password" type="password" required>
							</div>
				   
					 </fieldset>
                  
            
              </div>
              <div class="modal-footer">
               
                <button class="btn btn-md btn-warning btn-block" name="register">Sign Up</button>
				
				 <button type="button" class="btn btn-md btn-success btn-block" data-dismiss="modal">Cancel</button>
				   </form>
              </div>
            </div>
          </div>
        </div>
<!-- Script -->


     <div class="modal fade" id="ln" tabindex="-1" role="dialog" aria-labelledby="myMediulModalLabel">
          <div class="modal-dialog modal-sm">
            <div style="color:white;background-color:#008CBA" class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 style="color:white" class="modal-title" id="myModalLabel">Customer Login</h4>
              </div>
              <div class="modal-body">
            
				
				 <form role="form" method="post" action="userlogin.php">
                   <fieldset>
					
						
                            <div class="form-group">
                                <input class="form-control" placeholder="Email" name="user_email" type="email" required>
							</div>
							
							<div class="form-group">
                                <input class="form-control" placeholder="Password" name="user_password" type="password" required>
							</div>
				   
					 </fieldset>
                  
            
              </div>
              <div class="modal-footer">
               
                <button class="btn btn-md btn-warning btn-block" name="user_login">Sign In</button>
				
				 <button type="button" class="btn btn-md btn-success btn-block" data-dismiss="modal">Cancel</button>
				   </form>
				   
              </div>
            </div>
          </div>
        </div>
		
		<div class="modal fade" id="an" tabindex="-1" role="dialog" aria-labelledby="myMediulModalLabel">
          <div class="modal-dialog modal-sm">
           <div style="color:white;background-color:#008CBA" class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 style="color:white" class="modal-title" id="myModalLabel">Administrator Credentials</h4>
              </div>
              <div class="modal-body">
            
				
				 <form role="form" method="post" action="adminlogin.php">
                   <fieldset>
					
						
                            <div class="form-group">
                                <input class="form-control" placeholder="Username" name="admin_username" type="text" required>
							</div>
							
							<div class="form-group">
                                <input class="form-control" placeholder="Password" name="admin_password" type="password" required>
							</div>
				   
					 </fieldset>
                  
            
              </div>
              <div class="modal-footer">
               
                <button class="btn btn-md btn-warning btn-block" name="admin_login">Login</button>
				
				 <button type="button" class="btn btn-md btn-success btn-block" data-dismiss="modal">Cancel</button>
				   </form>
              </div>
            </div>
          </div>
        </div>
		 <br />
			 <br />
			 <br />
<!-- Script -->
     <!-- CONTACT SECTION END-->
    <div id="footer">
          Dream Automobiles Ltd| All Rights Reserved |  <a style="color: #fff" target="_blank">Design by : Top Tech 250</a>
    </div>
     <!-- FOOTER SECTION END-->
   
    <!--  Jquery Core Script -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!--  Core Bootstrap Script -->
    <script src="assets/js/bootstrap.js"></script>
    <!--  Flexslider Scripts --> 
         <script src="assets/js/jquery.flexslider.js"></script>
     <!--  Scrolling Reveal Script -->
    <script src="assets/js/scrollReveal.js"></script>
    <!--  Scroll Scripts --> 
    <script src="assets/js/jquery.easing.min.js"></script>
    <!--  Custom Scripts --> 
         <script src="assets/js/custom.js"></script>
</body>
</html>
